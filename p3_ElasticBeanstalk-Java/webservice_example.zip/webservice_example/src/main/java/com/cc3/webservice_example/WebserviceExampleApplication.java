package com.cc3.webservice_example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebserviceExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebserviceExampleApplication.class, args);
	}

}
